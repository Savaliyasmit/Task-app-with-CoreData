import UIKit
import PlaygroundSupport
import Foundation
PlaygroundPage.current.needsIndefiniteExecution = true


// API
// What are API/REST API/WebService
// Why are they used in mobile applications
// How to get data from API using Swift

//get
//func getUsersTodo(){
//    let session = URLSession.shared
//    let url  = URL(string: "https://jsonplaceholder.typicode.com/todos/1")!
//    
//    let tasks = session.dataTask(with: url) { data, statusCode, error in
//        if error == nil {
//            let code = statusCode as! HTTPURLResponse
//            if code.statusCode == 200 {
//                
//                let jsonData = try? JSONSerialization.jsonObject(with: data!, options: .mutableContainers)
//                
//                let result =  jsonData as! Dictionary<String,Any>
//                print(result["title"])
//            }
//              
//            
//            
//        }
//    }
//    tasks.resume()
//}
//
//getUsersTodo()

struct EndPoint {
    static let registerUser = "http://api-dev-scus-demo.azurewebsites.net/api/User/RegisterUser"
    static let getUser = "http://api-dev-scus-demo.azurewebsites.net/api/User/GetUser"
}

/*
struct User {
    func createUser()   {
        
        guard let validUrl =  URL(string: EndPoint.registerUser) else { return print("this is not vlaid url") }
        var url = URLRequest(url: validUrl)
        url.httpMethod = "post"
        
        let bodyDataSend:[String:Any] = ["name":"ss","email":"ss321@gmail.com","password":"1s23"]
        
        do {
            //it convert inot json ass on urlRequest
            let reqestBody = try JSONSerialization.data(withJSONObject: bodyDataSend , options: .prettyPrinted)
            url.httpBody = reqestBody
            url.addValue("application/json", forHTTPHeaderField: "content-type")
        }catch let error{
            print(error)
            
        }
        
        URLSession.shared.dataTask(with: url) {  data , responseCode , error in
          
            if( data != nil && data?.count != 0 ){
                
                let respones = String(data:data!  , encoding: .utf8)
                print(respones)
                
            }else {
                print(error)
            }
            
        }.resume()
    }
    
    func getUser(){
        guard let validUrl =  URL(string: EndPoint.getUser) else { return print("this is not vlaid url") }
        var urlRequest = URLRequest(url: validUrl)
        urlRequest.httpMethod = "get"
        URLSession.shared.dataTask(with: urlRequest){ data , responseCode, error in
            if( data != nil && data?.count != 0 ){
                
                let respones = String(data:data!  , encoding: .utf8)
                print(respones)
                
            }else {
                print(error)
            }
            
        }.resume()
    }
}

let userObj = User()
//userObj.createUser()
userObj.getUser()

 */

//Encodeable protocole
struct userRegestration:Encodable {
    let name  , email , password :String
    
//    enum CodingKeys: String , CodingKey {
//        //it use when json key diffrent so it set key e.g First_Name
//    case firstName = "First_Name"
//    case LastName =  "Last_Name"
//    case Email
//    case Password
//    }
}

struct Response: Decodable {
    let errorMessage: String
    let data: UserResponse

  
}

// MARK: - DataClass
struct UserResponse: Decodable {
    let name, email, id, joining: String
}


struct UserApi {
    func userSignup(){
        guard let validUrl =  URL(string: EndPoint.registerUser) else { return print("this is not vlaid url") }
        var url = URLRequest(url: validUrl)
        url.httpMethod = "post"
        url.addValue("application/json", forHTTPHeaderField: "content-type")
        
        let request  = userRegestration(name: "ssdd", email: "sss123@gmail.com", password: "323232323")
      
        do {
            //it convert inot json ass on urlRequest
            let reqestBody = try JSONEncoder().encode(request)
//            print(String(data:reqestBody , encoding: .utf8))
            url.httpBody = reqestBody
           
        }catch let error{
            print(error)
            
        }
        
        URLSession.shared.dataTask(with: url) {  data , responseCode , error in
          
            if( data != nil && data?.count != 0 ){
                
                do {
                    let decodeResponce = try JSONDecoder().decode(Response.self , from: data!)
                    print(decodeResponce)
                } catch let erros {
                    print(erros)
                }
                
            }else {
                print(error)
            }
            
        }.resume()
    }
}

let obj = UserApi()
obj.userSignup()
