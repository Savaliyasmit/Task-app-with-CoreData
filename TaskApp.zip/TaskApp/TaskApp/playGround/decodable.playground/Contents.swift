import UIKit
import PlaygroundSupport
import Foundation
PlaygroundPage.current.needsIndefiniteExecution = true
//
//"userId": 1,
//   "id": 1,
//   "title": "delectus aut autem",
//   "completed": false

struct todos: Codable {
    let userId , id :Int
    let title: String
    let completed:Bool
}

struct mainProducts: Codable {
    let status, message: String
    let products: [Product]
}

// MARK: - Product
struct Product: Codable {
    let id: Int
    let title: String
    let image: String
    let price: Int
    let description, brand, model: String
    let color: String?
    let category: Category
    let discount: Int?
    let popular, onSale: Bool?
}

enum Category: String, Codable {
    case audio = "audio"
    case gaming = "gaming"
    case mobile = "mobile"
    case tv = "tv"
}


struct Employee
{
    func getEmployee(){
//        let url = "https://jsonplaceholder.typicode.com/todos/1"
        //if array how use decodable strucure use [todos]
        let url = "https://jsonplaceholder.typicode.com/todos"
        URLSession.shared.dataTask(with: URL(string: url)!) {( data , responseCode, error) in
            guard let validData = data else {return }
            
            if let httpResponse = responseCode as? HTTPURLResponse {
                if httpResponse.statusCode != 200 {
                    print("Error: HTTP Status \(httpResponse.statusCode)")
                }else{
                    if (responseCode != nil &&  validData.count > 0 && error == nil  ){
                        do {                                   //when array of objects
                            let response = try JSONDecoder().decode([todos].self /*todos.self*/, from: validData)
                            for allTodos in response {
                                print("-->",allTodos.title)
                            }
                     
                        }catch let parseError {
                            print("Error ->",parseError)
                        }
                    }
                   
                }
                
                
            }

            print(error)
            
//
        }.resume()
    }
    
    func products(){
        let url = "https://fakestoreapi.in/api/products"
        URLSession.shared.dataTask(with: URL(string: url)!) {( data , responseCode, error) in
            guard let validData = data else {return }
            print(error)
            if (responseCode != nil &&  validData.count > 0 && error == nil  ){
                do {                                   //when array of objects
                    let response = try JSONDecoder().decode(mainProducts.self /*todos.self*/, from: validData)
                    print(response)
//                    for allTodos in response {
//                        print("-->",allTodos)
//                    }
             
                }catch let parseError {
                    print("Error ->",parseError)
                }
            }
           
//
        }.resume()
    }
}

var refer = Employee()
refer.getEmployee()
