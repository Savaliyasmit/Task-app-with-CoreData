import UIKit
import PlaygroundSupport
import Foundation
PlaygroundPage.current.needsIndefiniteExecution = true



struct todos: Decodable {
    let userId , id :Int
    let title: String
    let completed:Bool
}

struct mainProducts: Decodable {
    let status, message: String
    let products: [Product]
}

// MARK: - Product
struct Product: Decodable {
    let id: Int
    let title: String
    let image: String
    let price: Int
    let description, brand, model: String
    let color: String?
    let category: Category
    let discount: Int?
    let popular, onSale: Bool?
}

enum Category: String, Decodable {
    case audio = "audio"
    case gaming = "gaming"
    case mobile = "mobile"
    case tv = "tv"
}

struct HttpUtility {
   
    func getApi<T:Decodable>(url:URL ,  resultType: T.Type , comp: @Sendable @escaping(_ result: T) -> Void) {
        
        URLSession.shared.dataTask(with: url) {( data , responseCode, error) in
            guard let validData = data else {return }
            print(error)
            if (responseCode != nil &&  validData.count > 0 && error == nil  ){
                do {                                   //when array of objects
                    let response = try JSONDecoder().decode(T.self /*todos.self*/, from: validData)
                    comp(response)
             
                }catch let parseError {
                    print("Error ->",parseError)
                }
            }
           
    //
        }.resume()
    }
   
}

struct Employee {
    func getEmployee(){
        let url = "https://jsonplaceholder.typicode.com/todos"
        HttpUtility().getApi(url:URL(string: url)!, resultType: [todos].self){ (data) in
            for todo in data {
                print(todo)
            }
        }
    }
    
    
}

let refer = Employee()
refer.getEmployee()
