//
//  TodosManager.swift
//  TaskApp
//
//  Created by smit on 20/12/24.
//

import Foundation
import CoreData

struct TodosManager {
    
    private let repository =  TodoDataRepositroy()
    
    func createTask(task:Tasks){
        repository.create(task: task)
    }
    
    func getTasks() -> [Tasks]? {
        return repository.getAll()
    }
    
    func getTask( id:UUID) -> Tasks? {
        return repository.get(byId: id )
    }
    
    func updateTask(task:Tasks)  {
     repository.update(task: task)
    }
    
    func deleteTask(id:UUID) {
          repository.delete(id: id)
    }
    
    func removeAll(entityName: String) {
        return repository.deleteAllData(forEntity: entityName)
    }
}
