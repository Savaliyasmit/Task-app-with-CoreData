//
//  coreDataSingleTOn.swift
//  TaskApp
//
//  Created by smit on 23/12/24.
//

//import Foundation
//import CoreData
//
//// Task Structure
//struct Tasks {
//    var titlename: String
//    var id: UUID
//    var details: String?
//}
//
//// CoreDataHelper Singleton
//class CoreDataHelper {
//    
//    static let shared = CoreDataHelper() // Singleton instance
//    
//    private init() {} // Private initializer to prevent external initialization
//    
//    lazy var persistentContainer: NSPersistentContainer = {
//        let container = NSPersistentContainer(name: "TaskApp") // Replace with your actual data model name
//        container.loadPersistentStores { storeDescription, error in
//            if let error = error {
//                fatalError("Failed to load persistent stores: \(error)")
//            }
//        }
//        return container
//    }()
//    
//    var context: NSManagedObjectContext {
//        return persistentContainer.viewContext
//    }
//    
//    // Save context
//    func saveContext() {
//        if context.hasChanges {
//            do {
//                try context.save()
//            } catch {
//                print("Failed to save context: \(error)")
//            }
//        }
//    }
//    
//    // Fetch all data for a given entity
//    func fetcheAll<T: NSManagedObject>(managesObject: T.Type) -> [T]? {
//        let fetchRequest: NSFetchRequest<T> = T.fetchRequest()
//        do {
//            return try context.fetch(fetchRequest)
//        } catch {
//            print("Failed to fetch data: \(error)")
//            return nil
//        }
//    }
//}
//
//// Todo Data Repository
//protocol TodoRepsotioty {
//    func create(task: Tasks)
//    func get(byId id: UUID) -> Tasks?
//    func update(task: Tasks)
//    func delete(id: UUID)
//    func deleteAllData(forEntity entityName: String)
//}
//
//struct TodoDataRepositroy: TodoRepsotioty {
//    
//    func deleteAllData(forEntity entityName: String) {
//        let context = CoreDataHelper.shared.context
//        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: entityName)
//        let deleteRequest = NSBatchDeleteRequest(fetchRequest: fetchRequest)
//        
//        do {
//            try context.execute(deleteRequest)
//            try context.save()
//            print("\(entityName) entity data deleted successfully!")
//        } catch {
//            print("Failed to delete \(entityName) data: \(error)")
//        }
//    }
//    
//    func create(task: Tasks) {
//        let cdTodo = Todos(context: CoreDataHelper.shared.context)
//        cdTodo.titlename = task.titlename
//        cdTodo.id = task.id
//        CoreDataHelper.shared.saveContext()
//    }
//    
//    func getAll() -> [Tasks]? {
//        guard let result = CoreDataHelper.shared.fetcheAll(managesObject: Todos.self) else {
//            return nil
//        }
//        return result.map { $0.convertToTasks() }
//    }
//    
//    func get(byId id: UUID) -> Tasks? {
//        guard let result = getTaskById(byId: id) else { return nil }
//        return result.convertToTasks()
//    }
//    
//    func update(task: Tasks) {
//        guard let Todo = getTaskById(byId: task.id) else {
//            return
//        }
//        Todo.titlename = task.titlename
//        Todo.details = task.details ?? ""
//        CoreDataHelper.shared.saveContext()
//    }
//    
//    func delete(id: UUID) {
//        guard let Todo = getTaskById(byId: id) else {
//            return
//        }
//        CoreDataHelper.shared.context.delete(Todo)
//        do {
//            try CoreDataHelper.shared.context.save()
//        } catch {
//            print("Failed to save context after deletion: \(error)")
//        }
//    }
//    
//    private func getTaskById(byId id: UUID) -> Todos? {
//        let fetchRequest = NSFetchRequest<Todos>(entityName: "Todos")
//        let predicate = NSPredicate(format: "id == %@", id as CVarArg)
//        fetchRequest.predicate = predicate
//        do {
//            guard let result = try CoreDataHelper.shared.context.fetch(fetchRequest).first else {
//                return nil
//            }
//            return result
//        } catch {
//            print("Failed to fetch task by id: \(error)")
//            return nil
//        }
//    }
//}
//
//// Todos Manager (Main Interface)
//struct TodosManager {
//    private let repository = TodoDataRepositroy()
//    
//    func createTask(task: Tasks) {
//        repository.create(task: task)
//    }
//    
//    func getTasks() -> [Tasks]? {
//        return repository.getAll()
//    }
//    
//    func getTask(id: UUID) -> Tasks? {
//        return repository.get(byId: id)
//    }
//    
//    func updateTask(task: Tasks) {
//        repository.update(task: task)
//    }
//    
//    func deleteTask(id: UUID) {
//        repository.delete(id: id)
//    }
//    
//    func removeAll(entityName: String) {
//        repository.deleteAllData(forEntity: entityName)
//    }
//}

