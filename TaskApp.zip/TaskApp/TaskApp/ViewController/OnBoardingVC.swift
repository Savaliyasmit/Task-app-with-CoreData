//
//  OnBoardingVC.swift
//  TodoApp
//
//  Created by smit on 24/10/24.
//

import UIKit

class OnBoardingVC: UIViewController {

    var imgArray:[String] = ["SpalshScreen_1","SpalshScreen_2","SpalshScreen_3"]
    var currentIndex:Int = 0
    
    @IBOutlet weak var btnNext: UIButton!
    @IBOutlet weak var ClvView: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        btnNext.layer.borderWidth = 0
        btnNext.layer.cornerRadius = 20
        btnNext.layer.borderColor = UIColor.black.cgColor
        setupClvView()
    }
    
    func setupClvView(){
        ClvView.register(.init(nibName: "OnBoardingCell", bundle: nil), forCellWithReuseIdentifier: "OnBoardingCell")
        ClvView.dataSource = self
        ClvView.delegate = self
//        ClvView.isPagingEnabled = true
        ClvView.isUserInteractionEnabled = false
        ClvView.showsHorizontalScrollIndicator = false
        ClvView.reloadData()
    }
    
    @IBAction func OnBtnNext(_ sender: UIButton) {
        currentIndex += 1
        if currentIndex < imgArray.count {
            ClvView.scrollToItem(at: IndexPath(row: currentIndex, section: 0), at: .centeredHorizontally, animated: true)
        }else {
            isOnboarding = true
            guard  let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "HomeVC") as? HomeVC else { return }
            self.navigationController?.pushViewController(vc, animated: true)
            
        }
        
        
    }
}

extension OnBoardingVC:UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return  imgArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "OnBoardingCell", for: indexPath) as? OnBoardingCell else {
            return .init()
        }
        cell.imgOnBoarding.image =  UIImage(named: "\(imgArray[indexPath.row])")
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        return CGSize(width: UIScreen.main.bounds.size.width, height:UIScreen.main.bounds.height)
    }
      
}
