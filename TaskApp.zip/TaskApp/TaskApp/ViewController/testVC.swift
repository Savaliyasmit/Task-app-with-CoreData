import UIKit
import PhotosUI
import PDFKit

// MARK: - PDF Converter Utility
class ImageToPDFConverter {
    enum PageSize {
        case a3
        case a4
        case custom(width: CGFloat, height: CGFloat)
        
        var size: CGSize {
            switch self {
            case .a3:
                return CGSize(width: 297 * 2.83465, height: 420 * 2.83465) // mm to points
            case .a4:
                return CGSize(width: 210 * 2.83465, height: 297 * 2.83465) // mm to points
            case .custom(let width, let height):
                return CGSize(width: width, height: height)
            }
        }
    }
    
    static func convertImagesToPDF(
        images: [UIImage],
        pageSize: PageSize = .a4,
        progressHandler: ((Float) -> Void)? = nil,
        completion: @escaping (Result<Data, Error>) -> Void
    ) {
        DispatchQueue.global(qos: .userInitiated).async {
            let pdfData = NSMutableData()
            UIGraphicsBeginPDFContextToData(pdfData, CGRect(origin: .zero, size: pageSize.size), nil)
            
            for (index, image) in images.enumerated() {
                autoreleasepool {
                    UIGraphicsBeginPDFPage()
                    
                    let imageRect = AVMakeRect(
                        aspectRatio: image.size,
                        insideRect: CGRect(origin: .zero, size: pageSize.size)
                    )
                    
                    image.draw(in: imageRect)
                    
                    let progress = Float(index + 1) / Float(images.count)
                    DispatchQueue.main.async {
                        progressHandler?(progress)
                    }
                }
            }
            
            UIGraphicsEndPDFContext()
            
            DispatchQueue.main.async {
                completion(.success(pdfData as Data))
            }
        }
    }
}

// MARK: - Main View Controller
class PDFConverterViewController: UIViewController {
    // MARK: - UI Components
    private let imageStackView: UIStackView = {
        let stack = UIStackView()
        stack.axis = .horizontal
        stack.spacing = 8
        stack.distribution = .fillEqually
        stack.translatesAutoresizingMaskIntoConstraints = false
        return stack
    }()
    
    private let convertButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Convert to PDF", for: .normal)
        button.backgroundColor = .systemBlue
        button.setTitleColor(.white, for: .normal)
        button.layer.cornerRadius = 8
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    
    private let selectImagesButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("Select Images", for: .normal)
        button.backgroundColor = .systemGreen
        button.setTitleColor(.white, for: .normal)
        button.layer.cornerRadius = 8
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    
    private let progressView: UIProgressView = {
        let progress = UIProgressView(progressViewStyle: .default)
        progress.translatesAutoresizingMaskIntoConstraints = false
        return progress
    }()
    
    private let pageSizeSegment: UISegmentedControl = {
        let items = ["A4", "A3", "Custom"]
        let segment = UISegmentedControl(items: items)
        segment.selectedSegmentIndex = 0
        segment.translatesAutoresizingMaskIntoConstraints = false
        return segment
    }()
    
    // MARK: - Properties
    private var selectedImages: [UIImage] = []
    
    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        setupActions()
    }
    
    // MARK: - UI Setup
    private func setupUI() {
        title = "PDF Converter"
        view.backgroundColor = .systemBackground
        
        view.addSubview(imageStackView)
        view.addSubview(selectImagesButton)
        view.addSubview(convertButton)
        view.addSubview(progressView)
        view.addSubview(pageSizeSegment)
        
        NSLayoutConstraint.activate([
            imageStackView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            imageStackView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            imageStackView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            imageStackView.heightAnchor.constraint(equalToConstant: 200),
            
            pageSizeSegment.topAnchor.constraint(equalTo: imageStackView.bottomAnchor, constant: 20),
            pageSizeSegment.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            
            selectImagesButton.topAnchor.constraint(equalTo: pageSizeSegment.bottomAnchor, constant: 20),
            selectImagesButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            selectImagesButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            selectImagesButton.heightAnchor.constraint(equalToConstant: 44),
            
            convertButton.topAnchor.constraint(equalTo: selectImagesButton.bottomAnchor, constant: 12),
            convertButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            convertButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            convertButton.heightAnchor.constraint(equalToConstant: 44),
            
            progressView.topAnchor.constraint(equalTo: convertButton.bottomAnchor, constant: 20),
            progressView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            progressView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20)
        ])
    }
    
    private func setupActions() {
        selectImagesButton.addTarget(self, action: #selector(selectImagesButtonTapped), for: .touchUpInside)
        convertButton.addTarget(self, action: #selector(convertButtonTapped), for: .touchUpInside)
    }
    
    // MARK: - Actions
    @objc private func selectImagesButtonTapped() {
        var config = PHPickerConfiguration()
        config.selectionLimit = 10
        config.filter = .images
        
        let picker = PHPickerViewController(configuration: config)
        picker.delegate = self
        present(picker, animated: true)
    }
    
    @objc private func convertButtonTapped() {
        guard !selectedImages.isEmpty else {
            showError(message: "Please select images first")
            return
        }
        
        let pageSize: ImageToPDFConverter.PageSize
        switch pageSizeSegment.selectedSegmentIndex {
        case 0:
            pageSize = .a4
        case 1:
            pageSize = .a3
        case 2:
            pageSize = .custom(width: 612, height: 792) // US Letter size
        default:
            pageSize = .a4
        }
        
        convertButton.isEnabled = false
        selectImagesButton.isEnabled = false
        
        ImageToPDFConverter.convertImagesToPDF(
            images: selectedImages,
            pageSize: pageSize,
            progressHandler: { [weak self] progress in
                self?.progressView.progress = progress
            }
        ) { [weak self] result in
            self?.convertButton.isEnabled = true
            self?.selectImagesButton.isEnabled = true
            
            switch result {
            case .success(let pdfData):
                self?.savePDF(data: pdfData)
            case .failure(let error):
                self?.showError(message: error.localizedDescription)
            }
        }
    }
    
    // MARK: - Helper Methods
    private func savePDF(data: Data) {
        // Get the documents directory
        guard let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else {
            showError(message: "Could not access documents directory")
            return
        }
        
        // Create a unique filename with timestamp
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd-HHmmss"
        let timestamp = dateFormatter.string(from: Date())
        let filename = "converted_images_\(timestamp).pdf"
        
        // Create the file URL
        let pdfUrl = documentsDirectory.appendingPathComponent(filename)
        
        do {
            // Check if file already exists and remove it
            if FileManager.default.fileExists(atPath: pdfUrl.path) {
                try FileManager.default.removeItem(at: pdfUrl)
            }
            
            // Write the PDF data
            try data.write(to: pdfUrl, options: .atomic)
            
            // Verify file exists after saving
            if FileManager.default.fileExists(atPath: pdfUrl.path) {
                print("PDF saved successfully at: \(pdfUrl.path)")
                showSuccess(path: pdfUrl)
            } else {
                showError(message: "File was not saved successfully")
            }
        } catch {
            showError(message: "Failed to save PDF: \(error.localizedDescription)")
            print("Error saving PDF: \(error)")
        }
    }
    
    private func showSuccess(path: URL) {
        let activityVC = UIActivityViewController(
            activityItems: [path],
            applicationActivities: nil
        )
        present(activityVC, animated: true)
    }
    
    private func showError(message: String) {
        let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
    
    private func updateImagePreview() {
        imageStackView.arrangedSubviews.forEach { $0.removeFromSuperview() }
        
        for image in selectedImages.prefix(4) {
            let imageView = UIImageView(image: image)
            imageView.contentMode = .scaleAspectFit
            imageView.clipsToBounds = true
            imageView.layer.cornerRadius = 8
            imageView.backgroundColor = .systemGray6
            imageStackView.addArrangedSubview(imageView)
        }
    }
}

// MARK: - PHPicker Delegate
extension PDFConverterViewController: PHPickerViewControllerDelegate {
    func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
        picker.dismiss(animated: true)
        
        selectedImages.removeAll()
        let group = DispatchGroup()
        
        results.forEach { result in
            group.enter()
            result.itemProvider.loadObject(ofClass: UIImage.self) { [weak self] reading, error in
                defer { group.leave() }
                guard let image = reading as? UIImage else { return }
                DispatchQueue.main.async {
                    self?.selectedImages.append(image)
                }
            }
        }
        
        group.notify(queue: .main) { [weak self] in
            self?.updateImagePreview()
        }
    }
}
