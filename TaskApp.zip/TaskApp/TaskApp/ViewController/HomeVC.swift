
//  TestVC.swift
//  TodoApp
//
//  Created by smit on 15/10/24.
//

import UIKit

//protocol didUpdateData:AnyObject {
//    func updatedTask(index:Int , details:String)
//}

class HomeVC: UIViewController, UISearchControllerDelegate/*,didUpdateData*/ {
   
    @IBOutlet private weak var circleView: UIView!
    @IBOutlet private weak var tblView: UITableView!
    @IBOutlet  private weak var tblViewShow: UIView!
    @IBOutlet private weak var emptyImgShow: UIView!
    @IBOutlet private weak var deleteAllBtnShow: UIView!
    @IBOutlet weak var isSercheShow: UIView!
    
    private let todosManager:TodosManager =  TodosManager()
    private var isSercheVisible = false
    private let refresh = UIRefreshControl()
    
    var sercheCtr = UISearchController(searchResultsController: nil)
    var filterArray:[Tasks]?
    var lastContentOffset: CGFloat = 0
    var tasksList:[Tasks] = []

    
    override func viewDidLoad() {
        super.viewDidLoad()
        loadTask()
        circleView.layer.cornerRadius = circleView.frame.width / 2
        sercheCtr.isActive = false
        setupSercheBar()
        setupTblView()
        updateEmptyState()
        deleteAllBtnState()
        setupRefreshCtr()
    
//        fetchData(){
//            print("gfmnc,b,bf,gbg")
//
//        }
        
    
    }
//    func fetchData(completion:@escaping () -> Void) {
//        DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
//            completion()
//        }
//    }
    
  func loadTask(){
        if let tasks  = todosManager.getTasks(){
            print("--->",tasks)
            tasksList.append(contentsOf: tasks)
        }
    
    }

   
//    private func fetchTodos(){
//        do{
//            
//            let path  = FileManager.default.urls(for: .documentDirectory, in:.userDomainMask )
//            debugPrint(path[0])
//            guard  let result  =  try coreDataHelper.shared.context.fetch(Todos.fetchRequest()) as? [Todos] else {
//                return
//            }
//            
//            for todo in result {
//                
//                print("----------->",todo.titlename )
//            }
//            
//        }catch let error {
//            print("-----> Error",error)
//        }
//    }
//

    private func setupRefreshCtr(){
        tblView.refreshControl = refresh
        //        tblView.addSubview(refresh)
        //        refresh.translatesAutoresizingMaskIntoConstraints = false
        //        NSLayoutConstraint.activate([
        //            refresh.centerXAnchor.constraint(equalTo: tblView.centerXAnchor),
        //            refresh.centerYAnchor.constraint(equalTo: tblView.centerYAnchor)
        //        ])
        refresh.addTarget(self, action: #selector(refreshTableData(_:)), for: .valueChanged)
        refresh.tintColor = UIColor.white
        
    }
    
    private  func setupTblView(){
        tblView.register(.init(nibName: "TodoCell", bundle: nil), forCellReuseIdentifier: "TodoCell")
        tblView.dataSource = self
        tblView.delegate = self
        tblView.layer.cornerRadius =  10
        tblView.layer.borderWidth = 1
        tblView.layer.borderColor = UIColor.white.cgColor
    
    }
    
 private func deleteAllBtnState(){
            if !tasksList.isEmpty{
                isSercheShow.isHidden = false
                deleteAllBtnShow.isHidden = false
            }else{
                circleView.isHidden = false
                isSercheShow.isHidden = true
                deleteAllBtnShow.isHidden = true
            }
    
        }
        private func updateEmptyState(){
            if tasksList.count > 0{
    
                tblViewShow.isHidden = false
                emptyImgShow.isHidden = true
            }else{
    
                tblViewShow.isHidden = true
                emptyImgShow.isHidden = false
            }
        }
    
    private func setupSercheBar(){
        sercheCtr.delegate = self
        sercheCtr.searchResultsUpdater = self
        sercheCtr.obscuresBackgroundDuringPresentation = false
        sercheCtr.hidesNavigationBarDuringPresentation = false // Since no navigation bar
        
    }
    
    
    @objc private func refreshTableData(_ sender:UIRefreshControl){
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 2){ [weak self] in
            guard let self = self else { return }
            self.tblView.reloadData()
            sender.endRefreshing()
        }
    }
    
    
    @IBAction func btnSerche(_ sender: UIButton) {
        isSercheVisible.toggle()
        if self.isSercheVisible{
            tblView.refreshControl = nil
            UIView.animate(withDuration: 0.3){  [weak self] in
                guard let self = self else { return }
                self.tblView.tableHeaderView = self.sercheCtr.searchBar
                self.circleView.isHidden = true
            }
        }else{
            UIView.animate(withDuration: 0.3){ [weak self] in
                guard let self = self else { return }
                self.tblView.refreshControl = refresh
                self.tblView.tableHeaderView = nil
                self.filterArray = nil
                self.circleView.isHidden = false
                self.sercheCtr.isActive = false
                self.tblView.reloadData()
                
            }
        }
    }
    
    @IBAction private func btnAddTask(_ sender: Any) {
        
        let alertVc =  UIAlertController(title: "New Title", message: "add your Title", preferredStyle: .alert)
        
        alertVc.addTextField { textField in
            textField.placeholder = "Enter some text"
        }
        
        let addAction = UIAlertAction(title: "OK", style: .default) { [weak self] _ in
            guard let self  = self else {return}
            
            if let textField = alertVc.textFields?.first, let text = textField.text, !text.isEmpty , !text.trimmingCharacters(in: .whitespaces).isEmpty {
                
                //core DataCreate
                let task = Tasks(id: UUID(), titlename: text.capitalized )
                todosManager.createTask(task: task)
                tasksList.append(contentsOf: Array(arrayLiteral:task ))
                                self.updateEmptyState()
                                self.deleteAllBtnState()
                          
                if tasksList.count == 1 {
                                    self.tblView.reloadData()
                                } else {
                                    let newIndexPath = IndexPath(row: tasksList.count - 1, section: 0)
                                    self.tblView.beginUpdates()
                                    self.tblView.insertRows(at: [newIndexPath] , with: .automatic)
                                    self.tblView.endUpdates()
                                }
                
            }
        }
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        alertVc.addAction(addAction)
        alertVc.addAction(cancelAction)
        present(alertVc, animated: true, completion: nil)
    }
    
        @IBAction func btnDeleteAll(_ sender: UIButton) {
            sercheCtr.isActive = false
            
            let alertVc =  UIAlertController(title: "DeleteAll Task", message: "Are you sure you want to delete All task?", preferredStyle: .alert)
            let cancelAction = UIAlertAction(title: "Cancel", style: .cancel,handler: nil)
            let deleteAction = UIAlertAction(title: "Delete", style: .destructive){ [weak self] _ in
                guard let self = self else {return}
               
                self.sercheCtr.isActive = false
                self.sercheCtr.searchBar.text = nil
                self.todosManager.removeAll(entityName: "Todos")
                self.tasksList.removeAll()
                self.filterArray = nil
                self.updateEmptyState()
                self.deleteAllBtnState()
                self.tblView.reloadData()
            }
            alertVc.addAction(cancelAction)
            alertVc.addAction(deleteAction)
            self.present(alertVc,animated: true)
        }
    
    
            }
    
    extension HomeVC:UITableViewDataSource,UITableViewDelegate {
        func  tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            
            return  filterArray?.count ?? tasksList.count //filterArray?.count ?? tasksList.count
        }
        
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "TodoCell") as? TodoCell else{
                return .init()
            }
            //            cell.lblTask.text = "\( filterArray?[indexPath.row] ?? tasksList[indexPath.row])"
            
            let tasks = filterArray?[indexPath.row] ?? tasksList[indexPath.row]
            cell.lblTask.text = tasks.titlename
            cell.layer.cornerRadius =  10
            cell.layer.borderWidth = 1
            cell.layer.borderColor = UIColor.black.cgColor
            return cell
        }
        
        func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
            return 100
        }
        
        func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
            if self.sercheCtr.isActive {
                self.sercheCtr.isActive = false
                return nil
            }
            let task = self.tasksList[indexPath.row]
            
            let deleteAction = UIContextualAction(style: .destructive, title: "Delete") { (action, view, handler)  in
                print(indexPath.row)
                let currentTitle:String =  task.titlename
                
//                if let filterArray = self.filterArray{
//                    self.sercheCtr.isActive = false
//                    currentTitle = filterArray[indexPath.row]
//                } else {
//                    self.sercheCtr.isActive = false
//                    //                    currentTitle = titles[indexPath.row]
//                }
                
                let alertVc =  UIAlertController(title: "Delete Task", message: "Are you sure you want to delete this \(currentTitle) task?", preferredStyle: .alert)
                
                let cancelAction = UIAlertAction(title: "Cancel", style: .cancel){ _ in
                    handler(false)
                }
                let addAction = UIAlertAction(title: "Delete", style: .destructive) { [weak self] _ in
                    guard let self = self else {return}
                    tasksList.remove(at: indexPath.row)
                    let id  = task.id
                    self.todosManager.deleteTask(id: id)
                    tableView.deleteRows(at: [IndexPath(row: indexPath.row, section: 0)], with: .automatic)
                    self.updateEmptyState()
                    self.deleteAllBtnState()
                    handler(true)
                    
                }
                alertVc.addAction(addAction)
                alertVc.addAction(cancelAction)
                
                self.present(alertVc, animated: true, completion: nil)
                
            }
            return UISwipeActionsConfiguration(actions: [deleteAction])
            
        }

        func tableView(_ tableView: UITableView, leadingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
            
            if self.sercheCtr.isActive {
                self.sercheCtr.isActive = false
                return nil
            }
            
            let task = tasksList[indexPath.row]
            let currentTitle:String =  task.titlename
          
            if self.sercheCtr.isActive {
                self.sercheCtr.isActive = false
            }
            

            let ModifyAction = UIContextualAction(style: .normal, title: "Modify") { (action, view, handler) in
                
                let alertVc =  UIAlertController(title: "Modify Title", message: "Are you sure you want to Modify this \(currentTitle) task?", preferredStyle: .alert)
                
                alertVc.addTextField { textField in
                    textField.placeholder = "Entre Title Here"
                    textField.text = ""
                }
                
                let addAction = UIAlertAction(title: "Modify", style: .destructive) { [weak self] _ in
                    guard self != nil else {return}
                    if let textField = alertVc.textFields?.first, let newTitle = textField.text?.capitalized, !newTitle.isEmpty {
                        guard let self = self else {return}
                        tasksList[indexPath.row].titlename = newTitle
                        let updateTask:Tasks = Tasks(id: task.id, titlename:newTitle)
                        todosManager.updateTask(task:updateTask)
                        tableView.reloadRows(at: [indexPath], with: .automatic)
                        //                        tableView.reloadRows(at: [indexPath], with: .automatic)
                        handler(true)
                    }else{
                        handler(false)
                    }
                }
                
                let cancelAction = UIAlertAction(title: "Cancel", style: .cancel){_ in
                    handler(false)
                }
            
                alertVc.addAction(addAction)
                alertVc.addAction(cancelAction)
                
                self.present(alertVc, animated: true, completion: nil)
                
                
            }
            ModifyAction.backgroundColor = UIColor(named: "b_Color")
            return UISwipeActionsConfiguration(actions: [ModifyAction])
            
        }
        
        func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
            let  selectedTitle =  filterArray?[indexPath.row] ?? tasksList[indexPath.row]
            sercheCtr.isActive = false
            guard let EditVc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "TodoEditVC") as? TodoEditVC else {
                return
                
            }
            let originalIndex = tasksList.firstIndex(where: { $0.titlename == selectedTitle.titlename }) ?? indexPath.row
            
            EditVc.recivedIndex =  originalIndex
            EditVc.recivedTask = selectedTitle
          
            EditVc.comp = { [weak self] index, details  in
                guard let self = self else {return}
                
                self.tasksList[index].details = details
                
                if let filterIndex = self.filterArray?.firstIndex(where: { $0.titlename == self.tasksList[index].titlename }) {
                            self.filterArray?[filterIndex].details = details
                    self.tblView.reloadRows(at: [IndexPath(row: filterIndex, section: 0)], with: .none)
                        }
                
                self.tblView.reloadRows(at: [IndexPath(row: index, section: 0)], with: .none)
            }
            self.navigationController?.pushViewController(EditVc, animated: true)
        }
        
        func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
            cell.transform = CGAffineTransform(translationX: 0, y: tableView.bounds.size.height / 2)
            UIView.animate(withDuration: 0.8, delay: 0.03 * Double(indexPath.row), usingSpringWithDamping: 0.6, initialSpringVelocity: 0.1, options: .curveEaseInOut, animations: {
                cell.transform = CGAffineTransform.identity
            })
        }
        
        
    }
    
extension HomeVC: UISearchResultsUpdating {
    func updateSearchResults(for searchController: UISearchController) {
        if(sercheCtr.isActive == true){
            debounce(timeInterval: 0.5) {  [weak self]  in
                guard let self = self else { return }
                
                guard let text = searchController.searchBar.text, !text.isEmpty else {
                    // Clear filter and reload table once
                    self.filterArray = nil
                    self.tblView.reloadData()
                    return
                }
              
                self.filterArray  = self.tasksList.filter{ task in
                    return task.titlename.lowercased().contains(text.lowercased())
                }
                
                self.tblView.reloadSections(.init(integer: 0), with: .none)
            }
        }
        
    }
    
}

