//
//  TodoEditVC.swift
//  TodoApp
//
//  Created by smit on 07/10/24.
//

import UIKit
import IQKeyboardManagerSwift

//var tasks:[String:String]    {
//    get{
//        return UserDefaults.standard.dictionary(forKey: UniqueKey.list.rawValue) as? [String:String] ?? [:]
//    }
//    set{
//        UserDefaults.standard.set(newValue, forKey: UniqueKey.list.rawValue)
//    }
//}



class TodoEditVC: UIViewController {
    
    
    @IBOutlet weak var txtViewTask: UITextView!
    @IBOutlet weak var lblTitle: UILabel!
    
    var recivedTask:Tasks?
    var recivedIndex:Int = Int()
//    weak var delagate:didUpdateData?
    var comp:((_ recivedIndex: Int,_ details: String)->())?
  
    private let todosManager:TodosManager =  TodosManager()
    
    override func viewDidLoad() {
        setupTitle()
        super.viewDidLoad()
        print("-----<>",type(of: comp))
    }
   
//    override func viewWillAppear(_ animated: Bool) {
//        HomeVC().sercheCtr.isActive = false
//    }
    
    
    @IBAction func backToHomeBtn(_ sender: Any) {
//        delagate?.updatedTask(index: recivedIndex, details: txtViewTask.text)
        comp?(recivedIndex, txtViewTask.text)
        if !txtViewTask.text.isEmpty{
            save()
        }
        self.view.endEditing(true)
        self.navigationController?.popViewController(animated: true)
        
    }
    
   private func setupTitle(){
       if let task  = recivedTask {
            lblTitle.text = task.titlename
            txtViewTask.text = task.details
       }
    }

    private func save(){
        if let task  = recivedTask{
            todosManager.updateTask(task: Tasks(id: task.id, titlename: task.titlename, details: txtViewTask.text ))
        }
      }
    
}

