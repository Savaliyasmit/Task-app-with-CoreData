//
//  Todos+CoreDataClass.swift
//  TaskApp
//
//  Created by smit on 24/12/24.
//
//

import Foundation
import CoreData

@objc(Todos)
public class Todos: NSManagedObject {

}
