//
//  Users+CoreDataClass.swift
//  TaskApp
//
//  Created by smit on 24/12/24.
//
//

import Foundation
import CoreData

@objc(Users)
public class Users: NSManagedObject {

}
