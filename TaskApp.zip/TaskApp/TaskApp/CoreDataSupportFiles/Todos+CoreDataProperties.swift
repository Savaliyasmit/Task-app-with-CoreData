//
//  Todos+CoreDataProperties.swift
//  TaskApp
//
//  Created by smit on 24/12/24.
//
//

import Foundation
import CoreData


extension Todos {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Todos> {
        return NSFetchRequest<Todos>(entityName: "Todos")
    }

    @NSManaged public var details: String
    @NSManaged public var id: UUID
    @NSManaged public var titlename: String
    @NSManaged public var toUser: Users?

    func convertToTasks () -> Tasks {
        return  Tasks(id: self.id, titlename: self.titlename, details:self.details)
    }
}

extension Todos : Identifiable {

}
