//
//  TModel.swift
//  TaskApp
//
//  Created by smit on 19/12/24.
//

import Foundation

struct Tasks {
 let id:UUID
 var titlename:String
 var details:String?
}
