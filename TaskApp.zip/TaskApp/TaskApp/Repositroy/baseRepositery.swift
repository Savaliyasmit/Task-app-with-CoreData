//
//  baseRepositery.swift
//  TaskApp
//
//  Created by smit on 25/12/24.
//

import Foundation


