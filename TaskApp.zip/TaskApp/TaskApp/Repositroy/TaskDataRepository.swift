//
//  TaskDataRepository.swift
//  TaskApp
//
//  Created by smit on 19/12/24.
//
import Foundation
import CoreData

protocol TodoRepsotioty {
    func create(task:Tasks)
    func get(byId id: UUID) -> Tasks?
    func update(task: Tasks) 
    func delete(id: UUID)
    func deleteAllData(forEntity entityName: String)
}

struct TodoDataRepositroy:TodoRepsotioty {
    
    
func deleteAllData(forEntity entityName: String) {
    let context = coreDataHelper.shared.context
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: entityName)
        let deleteRequest = NSBatchDeleteRequest(fetchRequest: fetchRequest)
        
        do {
            try context.execute(deleteRequest)
            try context.save()
            print("\(entityName) entity data deleted successfully!")
        } catch {
            print("Failed to delete \(entityName) data: \(error)")
        }
    }
    
    func create(task: Tasks) {
        let cdTodo = Todos(context: coreDataHelper.shared.context)
        cdTodo.titlename = task.titlename
        cdTodo.id =  task.id
        coreDataHelper.shared.saveContext()
    }
    
    func getAll() -> [Tasks]? {
        guard let result = coreDataHelper.shared.fetcheAll(managesObject: Todos.self) else {
             return nil // Return nil if no results are fetched
         }
         return result.map { $0.convertToTasks() } // Transform using map
    }
    
    func get(byId id: UUID) -> Tasks? {
            guard let result = getTaskById(byId: id) else { return nil }
        
        return result.convertToTasks()
        
    }
    
    func update(task: Tasks)  {
        guard let Todo  = getTaskById(byId: task.id) else {
            return
        }
        Todo.titlename = task.titlename
        Todo.details = task.details ?? ""
        coreDataHelper.shared.saveContext()
        
    }
    
   
    
    func delete(id: UUID) {
        guard let Todo  = getTaskById(byId: id) else {
            return
        }
        coreDataHelper.shared.context.delete(Todo)
        do {
               try coreDataHelper.shared.context.save()
           } catch {
               print("Failed to save context after deletion: \(error)")
           }
    }
    
    private  func getTaskById(byId id:UUID) -> Todos? {
        let fetchReqest = NSFetchRequest<Todos>(entityName: "Todos")
        let predicate = NSPredicate(format: "id==%@", id as CVarArg)
        
        fetchReqest.predicate = predicate
        do {
            guard  let result = try coreDataHelper.shared.context.fetch(fetchReqest).first else{
                return nil
            }
            return result
        } catch let error {
            print(error)
            return nil
  }

                
            }
    
    
}
